G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.8*
G04 #@! TF.CreationDate,2026-04-10T20:01:46+05:30*
G04 #@! TF.ProjectId,solenoid,736f6c65-6e6f-4696-942e-6b696361645f,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.8) date 2026-04-10 20:01:46*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10R,2.000000X1.905000*%
%ADD11O,2.000000X1.905000*%
%ADD12C,1.600000*%
%ADD13RoundRect,0.249999X0.850001X-0.850001X0.850001X0.850001X-0.850001X0.850001X-0.850001X-0.850001X0*%
%ADD14C,2.200000*%
%ADD15R,1.700000X1.700000*%
%ADD16C,1.700000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,IRLZ44N1*
X4287500Y6287500D03*
D11*
X4287500Y8827500D03*
X4287500Y11367500D03*
G04 #@! TD*
D12*
G04 #@! TO.C,r2*
X13787500Y19287500D03*
X6167500Y19287500D03*
G04 #@! TD*
D13*
G04 #@! TO.C,1N4007*
X13287500Y5167500D03*
D14*
X13287500Y12787500D03*
G04 #@! TD*
D15*
G04 #@! TO.C,solenoid1*
X2787500Y16287500D03*
D16*
X2787500Y18827500D03*
G04 #@! TD*
D12*
G04 #@! TO.C,r1*
X8787500Y6167500D03*
X8787500Y13787500D03*
G04 #@! TD*
D15*
G04 #@! TO.C,power1*
X2812500Y1037500D03*
D16*
X2812500Y-1502500D03*
G04 #@! TD*
D15*
G04 #@! TO.C,J1*
X12367500Y-1212500D03*
D16*
X9827500Y-1212500D03*
X7287500Y-1212500D03*
G04 #@! TD*
M02*
